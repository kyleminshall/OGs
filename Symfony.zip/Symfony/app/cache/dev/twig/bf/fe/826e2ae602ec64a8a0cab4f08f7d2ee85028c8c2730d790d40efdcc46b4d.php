<?php

/* OGClubBundle:Page:login.html.twig */
class __TwigTemplate_bffe826e2ae602ec64a8a0cab4f08f7d2ee85028c8c2730d790d40efdcc46b4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" class=\"no-js\">
\t<head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "\t</head>
\t<body>
\t\t<div id=\"signup\">
\t\t\t<a href=\"";
        // line 12
        echo $this->env->getExtension('routing')->getPath("signup");
        echo "\">
\t\t\t\t<button style=\"margin-top: 0; width: 100px; background-color:#56d8f8\" class=\"turquoise-flat-button\">Register</button>
\t\t\t</a> <!-- Button to go to the profile page (profile.php) -->
\t\t</div>
\t\t<div id=\"login\">
\t\t\t<div id=\"box\">
\t\t\t\t<form method=\"post\" action=\"\">
\t\t\t\t\t<img class=\"profile-img\" src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/avatar_2x.png"), "html", null, true);
        echo "\" alt=\"\"><!-- Green man profile picture -->
\t\t\t\t\t<p>
\t\t\t\t\t\t<input class=\"form\" id=\"Username\" name=\"username\" type=\"text\" placeholder=\"Username\" ><br> <!-- Username input box -->
\t\t\t\t\t\t<input class=\"form\" id=\"Password\" name=\"password\" type=\"password\" placeholder=\"Password\"><br> <!-- Password input box -->
\t\t\t\t\t\t<button type=\"submit\" name=\"submit\" class=\"btn btn-4 btn-4a\">Login</button> <!-- Login (submit) button -->
\t\t\t\t\t</p>
\t\t\t\t</form>
                ";
        // line 26
        if (array_key_exists("error", $context)) {
            echo "<h4 class='alert'>";
            echo twig_escape_filter($this->env, (isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "html", null, true);
            echo "</h4>";
        }
        // line 27
        echo "\t\t\t</div>
\t\t</div><!-- end login -->
\t</body>
    ";
        // line 30
        $this->displayBlock('javascripts', $context, $blocks);
        // line 34
        echo "</html>
";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "We're the OGs";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/default.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
            <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/component.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
        ";
    }

    // line 30
    public function block_javascripts($context, array $blocks = array())
    {
        // line 31
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/modernizr.custom.js"), "html", null, true);
        echo "\" type=\"text/javascript\"/>
        <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/like.js"), "html", null, true);
        echo "\" type=\"text/javascript\"/>
    ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 32,  99 => 31,  96 => 30,  90 => 7,  85 => 6,  82 => 5,  76 => 4,  71 => 34,  69 => 30,  64 => 27,  58 => 26,  48 => 19,  38 => 12,  33 => 9,  31 => 5,  27 => 4,  22 => 1,);
    }
}
