<?php

/* OGClubBundle:Page:post.html.twig */
class __TwigTemplate_b2d32704b7f90203f1835ae03894a788041782c519d95dc3fd59fc7a2c0a89de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'id' => array($this, 'block_id'),
            'picture' => array($this, 'block_picture'),
            'likes' => array($this, 'block_likes'),
            'comments' => array($this, 'block_comments'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<table id=\"post_";
        $this->displayBlock('id', $context, $blocks);
        echo "\" style=\"border-collapse:collapse;table-layout:fixed;box-shadow: 0px 0px 3px #484848;margin:40px 0 40px 0\" width=\"500px\" cellpadding=\"10px\">
    <tr>

        <td style=\"width:40px\">
            <img src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/"), "html", null, true);
        $this->displayBlock('picture', $context, $blocks);
        echo "\" alt=\"Profile\" height=\"50px\" width=\"50px\"/>
        </td>

        <td style=\"width:65%\">
            <p style=\"font-size:18px;color:#000;margin:0;\">
                <b>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "poster"), "html", null, true);
        echo "</b><br>
                <span style=\"font-size:12px;color:#494949;\">";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "submitted"), "html", null, true);
        echo "</span>
            </p>
        </td>

        <td style=\"width:30%;padding:0;\">
            <p style=\"font-size:14px;color:#000;text-align:right\">Likes :<br>Comments :
            </p>
        </td>

        <td style=\"width:5%;padding:0;\">
            <p style=\"font-size:14px;color:#000;text-align:center\">
                <span id=\"post_";
        // line 22
        $this->displayBlock("id", $context, $blocks);
        echo "_likes\">";
        $this->displayBlock('likes', $context, $blocks);
        echo "</span><br>";
        $this->displayBlock('comments', $context, $blocks);
        // line 23
        echo "            </p>
        </td>
    </tr>

    <tr>
        <td colspan=\"4\" style=\"word-wrap:break-word\"> 
            <p style=\"font-size:18px;color:#000\">";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "message"), "html", null, true);
        echo "</p>
            <br>
        </td>
    </tr>

    <tr style=\"background-color:#f6f6f6;\">
        <td colspan=\"4\" style=\"padding-left: 10px;\">
            <p id=\"likes_";
        // line 36
        $this->displayBlock("id", $context, $blocks);
        echo "\" style=\"font-size:12px;padding:0;text-align:left\">
            </p>
        </td>
    </tr>
    ";
        // line 40
        if (((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")) > 0)) {
            // line 41
            echo "        ";
            $this->env->loadTemplate("OGClubBundle:Page:post.html.twig", "389178501")->display($context);
            // line 43
            echo "    ";
        }
        // line 44
        echo "
    <tr style=\"background-color:#f6f6f6;border-top:1px solid black;\">
        <td colspan=\"4\" style=\"padding:5px\">
            <form style=\"margin:0;\" name=\"like\" action=\"\" method=\"post\">
                <textarea name=\"reply\" class=\"autoExpand\" placeholder=\"Reply...\" style=\"width:100%;resize:none;border:none;background:transparent;font-size:12px;outline:none;\" rows=\"1\" wrap=\"physical\"></textarea>
                <input type=\"hidden\" name=\"post\" value=\"'.\$post_number.'\">
                <div align=\"right\">
                    <input style=\"vertical-align:top;align:right\" type=\"submit\" name=\"comment\" value=\"Post\">
                </div>
            </form>
        </td>
    </tr>

    <tr style=\"background-color:#dddddd;\">
        <td colspan=\"4\" style=\"padding-left: 10px;\">
            <span style=\"font-size:12px;padding:0;display:block;float:left\">
                <a id=\"like_";
        // line 60
        $this->displayBlock("id", $context, $blocks);
        echo "\" style=\"text-decoration:none;color:#1F80C9;\" href=\"#\" onclick=\"like_add(";
        $this->displayBlock("id", $context, $blocks);
        echo ");return false;\"></a> 
            </span>
            <span style=\"font-size:12px;padding:0;display:block;float:right\">
                <a id=\"delete_";
        // line 63
        $this->displayBlock("id", $context, $blocks);
        echo "\" style=\"text-decoration:none;color:#FD0D1B;\" href=\"#\" onclick=\"delete_post(";
        $this->displayBlock("id", $context, $blocks);
        echo ");return false;\">Delete</a> 
            </span>
        </td>
    </tr>
</table>";
    }

    // line 1
    public function block_id($context, array $blocks = array())
    {
        echo "0";
    }

    // line 5
    public function block_picture($context, array $blocks = array())
    {
        echo "profile.jpg";
    }

    // line 22
    public function block_likes($context, array $blocks = array())
    {
        echo "0";
    }

    public function block_comments($context, array $blocks = array())
    {
        echo "0";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:post.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 22,  140 => 5,  134 => 1,  123 => 63,  115 => 60,  97 => 44,  94 => 43,  91 => 41,  89 => 40,  82 => 36,  72 => 29,  64 => 23,  58 => 22,  44 => 11,  40 => 10,  31 => 5,  23 => 1,);
    }
}


/* OGClubBundle:Page:post.html.twig */
class __TwigTemplate_b2d32704b7f90203f1835ae03894a788041782c519d95dc3fd59fc7a2c0a89de_389178501 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("OGClubBundle:Page:reply.html.twig");

        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "OGClubBundle:Page:reply.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:post.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 22,  140 => 5,  134 => 1,  123 => 63,  115 => 60,  97 => 44,  94 => 43,  91 => 41,  89 => 40,  82 => 36,  72 => 29,  64 => 23,  58 => 22,  44 => 11,  40 => 10,  31 => 5,  23 => 1,);
    }
}
