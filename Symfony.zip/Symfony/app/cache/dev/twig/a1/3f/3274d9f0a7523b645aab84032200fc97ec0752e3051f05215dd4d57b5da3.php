<?php

/* OGClubBundle:Page:main.html.twig */
class __TwigTemplate_a13f3274d9f0a7523b645aab84032200fc97ec0752e3051f05215dd4d57b5da3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" class=\"no-js\">
    <head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "    </head>
    <body style=\"font-family:helvetica;background-image:none;\">
        <div align=\"center\">
            <p style=\"font-size:22px; text-decoration:none; margin: 0\">
                <a href=\"";
        // line 12
        echo $this->env->getExtension('routing')->getPath("index");
        echo "\"><button class=\"turquoise-flat-button\" style=\"background:#FC4144\">Go Home</button></a> <!-- Button for returning to the home page -->
            </p>
        </div>
        <br>
        <br>
        <br>
        ";
        // line 18
        $this->env->loadTemplate("OGClubBundle:Page:submit.html.twig")->display($context);
        // line 19
        echo "        <br>
        <br>
        <hr width=\"50%\" noshade>
        <div align=\"center\" display=\"inline-block;\">
            ";
        // line 23
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        $context['_iterated'] = false;
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 24
            echo "                ";
            $this->env->loadTemplate("OGClubBundle:Page:main.html.twig", "2060295314")->display($context);
            // line 33
            echo "            ";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 34
            echo "                <br>
                <br>
                 <p style=\"font-size:22px; text-decoration:none\">
                     There doesn't seem to be anything here! Feel free to post!
                 </p>
                 <br>
                 <br>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "            ";
        if (((isset($context["total"]) ? $context["total"] : $this->getContext($context, "total")) > 10)) {
            // line 43
            echo "                <span>
                    <a style=\"text-decoration:none;color:#1F80C9;\" href=\"'.\$server.'?page='.(\$current_page-1).'\">Previous</a>&nbsp;
                    <a style=\"text-decoration:none;color:#1F80C9;\" href=\"'.\$server.'?page='.(\$current_page+1).'\">&nbsp;Next</a>
                </span>
            ";
        }
        // line 48
        echo "        </div>
    </body>
    ";
        // line 50
        $this->displayBlock('javascripts', $context, $blocks);
        // line 54
        echo "</html>";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Main";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/default.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
        ";
    }

    // line 50
    public function block_javascripts($context, array $blocks = array())
    {
        // line 51
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/expand.js"), "html", null, true);
        echo "\" type=\"text/javascript\"/>
        <link href=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/like.js"), "html", null, true);
        echo "\" type=\"text/javascript\"/>
    ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:main.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 52,  142 => 51,  139 => 50,  132 => 6,  129 => 5,  123 => 4,  119 => 54,  117 => 50,  113 => 48,  106 => 43,  103 => 42,  90 => 34,  77 => 33,  74 => 24,  56 => 23,  50 => 19,  48 => 18,  39 => 12,  33 => 8,  31 => 5,  27 => 4,  22 => 1,);
    }
}


/* OGClubBundle:Page:main.html.twig */
class __TwigTemplate_a13f3274d9f0a7523b645aab84032200fc97ec0752e3051f05215dd4d57b5da3_2060295314 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("OGClubBundle:Page:post.html.twig");

        $this->blocks = array(
            'id' => array($this, 'block_id'),
            'submitted' => array($this, 'block_submitted'),
            'count' => array($this, 'block_count'),
            'likes' => array($this, 'block_likes'),
            'people' => array($this, 'block_people'),
            'picture' => array($this, 'block_picture'),
            'replies' => array($this, 'block_replies'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OGClubBundle:Page:post.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 25
    public function block_id($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "post_number"), "html", null, true);
    }

    // line 26
    public function block_submitted($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "submitted"), "html", null, true);
    }

    // line 27
    public function block_count($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "count"), "html", null, true);
    }

    // line 28
    public function block_likes($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "likes"), "html", null, true);
    }

    // line 29
    public function block_people($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "people"), "html", null, true);
    }

    // line 30
    public function block_picture($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "profile"), "html", null, true);
    }

    // line 31
    public function block_replies($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "replies"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:main.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  236 => 31,  230 => 30,  224 => 29,  218 => 28,  212 => 27,  206 => 26,  200 => 25,  147 => 52,  142 => 51,  139 => 50,  132 => 6,  129 => 5,  123 => 4,  119 => 54,  117 => 50,  113 => 48,  106 => 43,  103 => 42,  90 => 34,  77 => 33,  74 => 24,  56 => 23,  50 => 19,  48 => 18,  39 => 12,  33 => 8,  31 => 5,  27 => 4,  22 => 1,);
    }
}
