<?php

/* OGClubBundle:Page:profile.html.twig */
class __TwigTemplate_b7938816362ae7a0b0ec9dbb6ca57e08ae09f85337ad3e9e74ea7c47686de34b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" class=\"no-js\">
\t<head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "\t</head>
\t<body style=\"background-image: none;\">
\t\t<div align=\"center\">

\t\t\t<p>
\t\t\t\tCurrent profile picture:<br><br>
\t\t\t\t<img src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/"), "html", null, true);
        echo twig_escape_filter($this->env, (isset($context["picture"]) ? $context["picture"] : $this->getContext($context, "picture")), "html", null, true);
        echo "\" 
\t\t\t\t\talt=\"Profile\" 
\t\t\t\t\theight=\"200px\" 
\t\t\t\t\twidth=\"200px\"
\t\t\t\t/> <!-- Show the profile picture the user currently has set -->
\t\t\t</p>
\t\t\t<p>
\t\t\t\t<form name=\"Image\" enctype=\"multipart/form-data\" action=\"\" method=\"POST\"> <!-- Form to upload a new picture -->
\t\t\t\t\t<input type=\"file\" name=\"Photo\" size=\"2000000\" accept=\"image/jpg, image/jpeg, image/png, image/x-png\" size=\"26\"></input> <!-- File upload submission button -->
\t\t\t\t\t<input type=\"submit\" class=\"button\" name=\"Submit\" value=\"Submit\"></input> <!-- Submit button -->
\t\t\t\t\t<input type=\"reset\" class=\"button\" value=\"Cancel\"></input> <!-- Cancel/Clear button -->
\t\t\t\t</form>
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 28
        echo $this->env->getExtension('routing')->getPath("index");
        echo "\"><button class=\"turquoise-flat-button\" style=\"background:#FC4144\">Go Home</button></a> <!-- Button to return back to the home direcotry -->
\t\t\t</p>
\t\t</div><!-- end main --> 
\t</body>
</html>";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Profile";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/default.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
        ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 6,  73 => 5,  67 => 4,  58 => 28,  40 => 14,  32 => 8,  30 => 5,  26 => 4,  21 => 1,);
    }
}
