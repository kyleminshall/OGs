<?php

/* OGClubBundle:Page:submit.html.twig */
class __TwigTemplate_db5838f4c94d518fa8ab20fc297ae0586548037a14e65f9f3d4a18210b202ec3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div align=\"center\">
    <form name=\"comments\" action=\"\" method=\"post\"> <!-- Form for comment submission -->
        <table width=\"500px\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"box-shadow: 0px 0px 3px #484848;\"> 
            <tr style=\"background-color: #f6f6f6\"> 
                <td>
                    <textarea class='autoExpand' data-min-rows='3' name=\"comment\" placeholder=\"Submit a post...\" style=\"width:480px;resize:none;border:none;padding:10px;background:transparent;font-size:18px;outline:none;\" rows=\"3\" wrap=\"VIRTUAL\"></textarea></textarea> <!-- Text area for typing into the post -->
                </td> 
            </tr> 
            <tr align=\"right\" style=\"background-color: #dddddd\"> 
                <td>
                    <input type=\"submit\" name=\"submit\" value=\"Submit\"> <!-- Button to submit the post -->
                </td> 
            </tr> 
        </table> 
    </form>
</div> ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:submit.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
