<?php

/* OGClubBundle:Page:signup.html.twig */
class __TwigTemplate_75737909d6c68314a76a5f7c90279e5325b656fc688251aa025db168855d721c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" class=\"no-js\">
\t<head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "\t</head>
\t<body>
\t\t<div id=\"login\">
\t\t\t<div id=\"box\">
\t\t\t\t<p>
\t\t\t\t\t<h1 style=\"color:#494949\">Register</h1> <!-- Register header text -->
\t\t\t\t</p>
\t\t\t\t<form method=\"post\" action=\"\">
\t\t\t\t\t<p style=\"margin-bottom:0\">
\t\t\t\t\t\t<input class=\"form\" id=\"number\" name=\"key\" type=\"text\" placeholder=\"Permission Key\" ><br> <!-- Box to type in the permission key -->
\t\t\t\t\t\t<input class=\"form\" id=\"Password\" name=\"firstName\" type=\"text\" placeholder=\"First Name\" ><br> <!-- Box to type in first name -->
\t\t\t\t\t\t<input class=\"form\" id=\"Password\" name=\"lastName\" type=\"text\" placeholder=\"Last Name\" ><br> <!-- Box to type in last name -->
\t\t\t\t\t\t<input class=\"form\" id=\"Password\" name=\"username\" type=\"text\" placeholder=\"Username\" ><br> <!-- Box to type in desired username -->
\t\t\t\t\t\t<input class=\"form\" id=\"Password\" name=\"password\" type=\"password\" placeholder=\"Password\"><br> <!-- Box to type in password -->
\t\t\t\t\t\t<input class=\"form\" id=\"Password\" name=\"cpassword\" type=\"password\" placeholder=\"Confirm Password\"><br> <!-- Box to confirm password -->
\t\t\t\t\t\t<button type=\"submit\" name=\"submit\" class=\"btn btn-4 btn-4a icon-arrow-right\" style=\"padding:10px 62px !important;\">Sign Up!</button> <!-- Signup/Submission button -->
\t\t\t\t\t</p>
\t\t\t\t</form>
\t\t\t\t<p style=\"margin-top:0\">
\t\t\t\t\t<a style=\"text-decoration:none\" href=\"index.php\">
\t\t\t\t\t\t<button class=\"btn back btn-4 btn-4a\" style=\"padding:10px 59px !important; background:#FC4144;color: #fff;\">Go Home</button>  <!-- Button to send the user back to the main page -->
\t\t\t\t\t</a>
\t\t\t\t</p>
\t\t\t\t";
        // line 32
        if (array_key_exists("error", $context)) {
            echo "<h4 class='alert'>";
            echo twig_escape_filter($this->env, (isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "html", null, true);
            echo "</h4>";
        }
        // line 33
        echo "\t\t\t</div>
\t\t</div><!-- end signup -->
\t</body>
    ";
        // line 36
        $this->displayBlock('javascripts', $context, $blocks);
        // line 39
        echo "</html>
";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Welcome to the Site";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/default.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
            <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/component.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
        ";
    }

    // line 36
    public function block_javascripts($context, array $blocks = array())
    {
        // line 37
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/modernizr.custom.js"), "html", null, true);
        echo "\" type=\"text/javascript\"/>
    ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:signup.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 4,  81 => 41,  53 => 23,  23 => 1,  124 => 31,  100 => 4,  104 => 32,  90 => 7,  76 => 4,  58 => 32,  126 => 1,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 5,  128 => 49,  107 => 61,  61 => 13,  273 => 96,  269 => 94,  254 => 92,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 6,  119 => 30,  102 => 32,  71 => 39,  67 => 41,  63 => 25,  59 => 24,  38 => 12,  94 => 29,  89 => 45,  85 => 6,  75 => 17,  68 => 14,  56 => 9,  87 => 25,  21 => 1,  26 => 4,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 4,  44 => 12,  31 => 5,  28 => 4,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 67,  156 => 66,  151 => 63,  142 => 59,  138 => 23,  136 => 56,  121 => 46,  117 => 44,  105 => 40,  91 => 27,  62 => 23,  49 => 1,  24 => 4,  25 => 3,  19 => 1,  79 => 18,  72 => 22,  69 => 36,  47 => 16,  40 => 14,  37 => 10,  22 => 1,  246 => 90,  157 => 56,  145 => 46,  139 => 45,  131 => 52,  123 => 47,  120 => 40,  115 => 64,  111 => 37,  108 => 36,  101 => 32,  98 => 31,  96 => 36,  83 => 5,  74 => 37,  66 => 15,  55 => 4,  52 => 19,  50 => 10,  43 => 8,  41 => 7,  35 => 7,  32 => 8,  29 => 4,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 66,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 29,  112 => 42,  109 => 6,  106 => 5,  103 => 32,  99 => 37,  95 => 28,  92 => 21,  86 => 6,  82 => 5,  80 => 19,  73 => 5,  64 => 33,  60 => 6,  57 => 22,  54 => 10,  51 => 19,  48 => 19,  45 => 15,  42 => 7,  39 => 12,  36 => 5,  33 => 9,  30 => 5,);
    }
}
