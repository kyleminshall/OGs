<?php

/* OGClubBundle:Page:reply.html.twig */
class __TwigTemplate_1aadf08fa8ac2cd0125685978e984466a11e24cdd9b9a8b36c3a7cc9a7271911 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'replyid' => array($this, 'block_replyid'),
            'picture' => array($this, 'block_picture'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<tr id=\"reply_";
        $this->displayBlock('replyid', $context, $blocks);
        echo "\" style=\"background-color:#f6f6f6;\">
    <td colspan=\"4\" style=\"position:relative\"> 
        <div style=\"float:left;position:absolute;padding-right:10px\"> 
            <img src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/"), "html", null, true);
        $this->displayBlock('picture', $context, $blocks);
        echo "\" alt=\"Profile\" height=\"30px\" width=\"30px\"/>
        </div><div style=\"float:right;display:block;\">
            <span style=\"color:ddd;font-size:12px\">
                <a class=\"reply_delete\" style=\"text-decoration:none;color:#ddd;\" href=\"#\" onclick=\"delete_reply(";
        // line 7
        $this->displayBlock("replyid", $context, $blocks);
        echo ");return false;\">X</a> 
            </span>
        </div>
        <p style=\"font-size:14px;color:000;margin:0;padding-left:40px;padding-right:20px;\">
            <b></b><br>
            <span style=\"font-size:12px;color:#494949;\"></span>
        </p>
    </td>
</tr>
";
    }

    // line 1
    public function block_replyid($context, array $blocks = array())
    {
        echo "0";
    }

    // line 4
    public function block_picture($context, array $blocks = array())
    {
        echo "profile.jpg";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:reply.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 4,  49 => 1,  35 => 7,  28 => 4,  21 => 1,);
    }
}
