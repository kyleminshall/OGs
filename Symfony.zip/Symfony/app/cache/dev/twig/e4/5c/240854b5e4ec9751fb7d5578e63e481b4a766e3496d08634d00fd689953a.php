<?php

/* OGClubBundle:Page:home.html.twig */
class __TwigTemplate_e45c240854b5e4ec9751fb7d5578e63e481b4a766e3496d08634d00fd689953a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" class=\"no-js\">
\t<head>
\t\t<title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "\t\t<script src=\"js/jquery-2.1.1.js\" type=\"text/javascript\" charset=\"utf-8\"></script> <!-- Gotta import that jquery -->
\t</head>
\t<body style=\"background-image: none;\">
\t\t<div id=\"main\">
\t\t\t<p>
\t\t\t\tSuccessfully authenticated user: <h1><b>";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "<b><h1><!-- Displaying that they were successfully authenticated -->
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("profile");
        echo "\"><button class=\"turquoise-flat-button\">Profile</button></a> <!-- Button to go to the profile page (profile.php) -->
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 19
        echo $this->env->getExtension('routing')->getPath("main");
        echo "\"><button class=\"turquoise-flat-button\">Main Board</button></a> <!-- Button to go to the comments page (comments.php) -->
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("progress");
        echo "\"><button class=\"turquoise-flat-button\">Progress</button></a> <!-- Link to the stuff that is currently in progress on the site (progress.php) -->
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("logout");
        echo "\"><button class=\"turquoise-flat-button\" style=\"background:#FC4144\">Log Out</button></a> <!-- Opens the logout.php to sign the user out of the site -->
\t\t\t</p>
\t\t</div><!-- end main -->

\t\t<div id=\"sidebar\">
\t\t\t<h1 style=\"text-align:center\">Activity</h1>
\t\t\t<hr style=\"color:black\" noshade>
            
            ";
        // line 33
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["activity"]) ? $context["activity"] : $this->getContext($context, "activity")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["act"]) {
            // line 34
            echo "    \t\t\t<div class=\"activity\">
    \t\t\t\t<p class=\"element\">
                        <a class=\"elem\" style=\"text-decoration:none;color:#000\" href=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["act"]) ? $context["act"] : $this->getContext($context, "act")), "server"), "html", null, true);
            echo "\"></a>
                        ";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["act"]) ? $context["act"] : $this->getContext($context, "act")), "message"), "html", null, true);
            echo "
                        <br>
                        <span style=\"font-size:12px;color:#494949\"> ";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["act"]) ? $context["act"] : $this->getContext($context, "act")), "time"), "html", null, true);
            echo "</span>
                    </p>
    \t\t\t</div>
    \t\t\t<hr class=\"activity\" style=\"color:black\" noshade>
            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 44
            echo "\t\t\t    <div class=\"activity\">
\t\t\t\t    <p class=\"element\" style=\"text-align:center\"> No recent activity. Feel free to post! </p>
\t\t\t    </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['act'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "            
            <!-- Spacer. Cheap, I know.-->
\t\t\t<div class=\"activity\">
\t\t\t    <p class=\"element\"></p>
\t\t\t</div>
\t\t\t<div class=\"replacement\">
\t\t\t    <p class=\"element\" id=\"replace\" style=\"text-align:center\"></p>
\t\t\t</div>
            <!-- End Spacer-->
            
\t\t</div>
        ";
        // line 59
        if ((!twig_test_empty((isset($context["activity"]) ? $context["activity"] : $this->getContext($context, "activity"))))) {
            echo "    
    \t\t<div id=\"sidebar-footer\">
    \t\t\t<p style=\"font-size:22px;text-decoration:none;margin:0;\">
            \t\t<a style=\"text-decoration:none\" href=\"#\" onclick=\"remove_activity(); return false;\">
            \t\t    <button class=\"mark-button activity\">Mark All As Read</button>
                    </a>
    \t\t\t</p>
            </div>
        ";
        }
        // line 68
        echo "        
\t\t<div id=\"notifications\">
\t\t\t<h1 style=\"text-align:center\">Notifications</h1>
\t\t\t<hr style=\"color:black\" noshade>
            
            ";
        // line 73
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["notifications"]) ? $context["notifications"] : $this->getContext($context, "notifications")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["notif"]) {
            // line 74
            echo "                <div class=\"notif\">
\t\t\t\t\t<p class=\"notif\">";
            // line 75
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["notif"]) ? $context["notif"] : $this->getContext($context, "notif")), "message"), "html", null, true);
            echo "<br></p>
                </div>
\t\t\t    <hr class=\"notif\" style=\"color:black;padding:0\" noshade>
            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 78
            echo "    
    \t\t\t<div class=\"notif\">
    \t\t\t\t<p class=\"notif\" style=\"text-align:center;margin:0\"> Nothing here! </p>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['notif'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 83
        echo "            
            <!-- Spacer. Cheap, I know.-->
            <div class=\"notif\">
\t\t\t    <p class=\"notif\"></p>
\t\t\t</div>
\t\t\t<div class=\"replacement\">
\t\t\t    <p class=\"element\" id=\"replace_notif\" style=\"text-align:center\"></p>
\t\t\t</div>
             <!-- End Spacer-->
             
        ";
        // line 93
        if ((!twig_test_empty((isset($context["notifications"]) ? $context["notifications"] : $this->getContext($context, "notifications"))))) {
            echo "         
\t\t</div>
\t\t\t<div id=\"notbar-footer\">
\t\t\t<p style=\"font-size:22px;text-decoration:none;margin:0;\">
\t\t\t    <a style=\"text-decoration:none\" href=\"#\" onclick=\"remove_notifs(); return false;\">
                    <button class=\"mark-button notif\">Mark All As Read</button>
                </a>
\t\t\t</p>
        </div>
        ";
        }
        // line 103
        echo "\t</body>
\t<script src=\"js/main.js\" type=\"text/javascript\" charset=\"utf-8\"></script>
</html>";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Success";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/default.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
        ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 6,  207 => 5,  201 => 4,  195 => 103,  182 => 93,  170 => 83,  160 => 78,  151 => 75,  148 => 74,  143 => 73,  136 => 68,  124 => 59,  111 => 48,  102 => 44,  92 => 39,  87 => 37,  83 => 36,  79 => 34,  74 => 33,  63 => 25,  57 => 22,  51 => 19,  45 => 16,  39 => 13,  32 => 8,  30 => 5,  26 => 4,  21 => 1,);
    }
}
