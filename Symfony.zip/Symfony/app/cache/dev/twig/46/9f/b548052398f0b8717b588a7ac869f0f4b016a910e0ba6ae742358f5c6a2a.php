<?php

/* OGClubBundle:Page:progress.html.twig */
class __TwigTemplate_469fb548052398f0b8717b588a7ac869f0f4b016a910e0ba6ae742358f5c6a2a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" class=\"no-js\">
\t<head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "\t</head>
\t<body style=\"background-image: none;\">
\t\t<div id=\"top\">
\t\t\t<center>
\t\t\t\t<p>
\t\t\t\t\tWebsite Version : 0.7.0<br> <!-- Current version of the site -->
\t\t\t\t\tThe OG Social Network <!-- Working title -->
\t\t\t\t</p>
\t\t\t</center>
\t\t</div>
\t\t<div id=\"main\" style=\"width:100%;margin-left:-50%;line-height:28px;\">
\t\t\t<p>
\t\t\t\t<b>Work in Progress:</b> <!-- Feature that is currently being worked on -->
\t\t\t\t<br>
                - Convert everything to Symfony 2 <br>
\t\t\t\t<br>
\t\t\t</p>
\t\t\t<p>
\t\t\t\t<b>Features to be worked on:</b> <!-- Features to be worked on at a later time -->
\t\t\t\t<br>
\t\t\t\t- @mentions (this will take a while) <br>
\t\t\t\t- Image posts (this will also take a while) <br>
\t\t\t\t- Chat system for messaging users <br>
\t\t\t\t<br>
\t\t\t\t<br>
\t\t\t</p>
\t\t\t<p>
\t\t\t\t<b>If you guys want to start developing:</b>
\t\t\t\t<br>
\t\t\t\t<a href=\"https://docs.google.com/document/d/1A2_5uLfmEyhjBgcmf-18gLY7lN3o17iSmO3ci6hDMRQ/edit?usp=sharing\">Engineering Intro!</a>
\t\t\t\t<br>
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 41
        echo $this->env->getExtension('routing')->getPath("index");
        echo "\"><button class=\"turquoise-flat-button\" style=\"background:#FC4144\">Go Home</button></a> <!-- Button to send the user back to the main page -->
\t\t\t</p>
\t\t</div><!-- end main --> 
\t</body>
</html>
";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Current Work In Progress";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/default.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
        ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:progress.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 6,  83 => 5,  77 => 4,  67 => 41,  32 => 8,  30 => 5,  26 => 4,  21 => 1,);
    }
}
