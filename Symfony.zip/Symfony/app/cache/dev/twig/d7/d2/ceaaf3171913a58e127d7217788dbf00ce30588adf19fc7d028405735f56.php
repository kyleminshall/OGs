<?php

/* WebProfilerBundle:Profiler:header.html.twig */
class __TwigTemplate_d7d2ceaaf3171913a58e127d7217788dbf00ce30588adf19fc7d028405735f56 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"header\" class=\"clear-fix\">
    <h1>
        <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAA+CAMAAAA/Mg/WAAAAjVBMVEXW1ta/v8Dh4eFgXmE8Oj7j4+PLy8unpqiPjpB4d3nIyMjX19dIRkro6OiYl5lUUlZsa22zsrTy8vLl5eU9Oz9KSEzs7OzBwcGEg4XLy8ybmpy9vb3ExMSxsbLa2tp+fH/Y2Nlxb3JXVVjPz89kYmWkpKXd3d3T09O+vr+LiYzMzMy6urowLjL////v7+/NfgWIAAAAL3RSTlP/////////////////////////////////////////////////////////////AFqlOPcAAAAJdnBBZwAAARMAAAA+AHci3fUAAAeMSURBVHja7Zvneuo4EIbdC65gOqGEEFIs+/4vbzWj5hLF5GySZxef7wcWtqVkXkYzIxmMWiNzu7btjJDMttdbsx6TPmQSbW3Skb2NxszERyB92f5Ymfgx0Sr2x8jEzMinis2xMXHXZFC5OyomXkZuUOyNiMnUITfJ8UfDxCc3yx8FE0TyFwpnopD8hdJm4jlkUOdjmh4XhMm8eyZuTIZ0LCrUfs4CbXTvTPJBHzlVVbogCwrlRFD2nTOZkgE9zqrqCM5SUV0IanvPTIZnzpmSeIbGpsHEce+ZSTCAZEG9ZDaXTESYDe+YiTuUc07gJnIOYQv1vwqziTGZPCWibVifMRl2k7SiOrP2/AJeoncUbxoE5hcXRD4ss356EXUoQYlRlpO6tsrS+JxJTHpaXC7z5sypCtKSJqJM4z8oXkJCfp5JsivLd+Olvo1JP+nMUyxFTm8Myx6rkluq2e2fTCoP8nrg/3SIYBRuZRJ+kHer2eZEXx7BTSrQEa/sU9JSXjdlwnTy6jr6UpwJYJgf1xOdN+gvllXcwKQTYS+iWF2ksyqFaCJyzSM9dqC4nUkQ1F9W+CuLp0lZyvYwE4+0VUD0kMXrHt9XMxFrN6Slad2Q/cVAonr915hsO8uaqmH5/FSdKnECZ9EraSn4mnWeaUbYiLDR72WanaTl0jO6sGlBPi0M45BwSy3auBoGfcULIuEuLct6KEuLCtpJi0lxgNvUgAkdz+iEk+eqmWXm+wr1LOqUCxHqL3ryxnuPtl3ejElYm8TxzJgQPO3Z2PDoWS7kErF/xQmgI/Qwo5yA1vSEI/c83YzEPFzW11UJmiAGamjyUDJzD7sSZSyBgBTSUExE/5UlBjSwk01a2lTtNDMTIXZx3MCxrbhVZ4Ch4uPPCNlKVFOwXvyhTOxLOFFEpKLad5o7vtAjdFQsD2U5tKaQuAm06NhNAMOuQCYvqxKZLCdgKF5ZFVomGHnLhwl0OvDcxECSrp+g3tRKR+n1TLrqhAaqMBJ5OcOGS40HCwHY1AyY0VPTd8A0WuHFtEsQTDEnO75pBg4UPrxHTE+Ar+Blp0bFFCBnwkwD55ggk135AO5fv9Omxa+sls14opjgCHA/HncJO4BjJV0mxwokPeKtQqVUj7yK0yceNySSSiTKFJ+eYBbaokKLXXY+bsaTjELE0TxH9ohdfkeIKKZ4WcA2EAloST/pKzDhAMB9CnaFQnnRMVnuAAUf6qUxYJcJThZVzL9i+0Q06gZVE13FmbIps+VTxwML8cAaPvcf0mDiqcF8YK1urKdIIeCTZ43j8k9ZVWRPyOTAkgw2UAk9qWNyxV6oXbmCUeC1zwQ9A1U0CL0OMOlR8dCynJkeMxQxuy6dq80kAMO5HIxAcrJEeGfE38eiv9FIHmANMAE3kQ0UJBwNkxf0LkGReUuPyTk9Yy3PdFThJB1m0n5MZLPVtotoAkAhcxKa1mdiq8SObdFD3Znh5PFk2WswawUFeHkQdk+6RX2fCZxryoJbr10mWKcqKK8qulxuZSJdIRIFag7tNhP7D5jIwLSGUXVMJv+WidVlsuEF65zXaSoLLTRENKu9DM004RN12ZQYZpIPMBEJLIYXlKFcf0mDqmKSqECDE+SgYfIODJS0TCqs1GbIhJ1CUFppy3U+831CfD0TfTwx+0yw0PHQWVSyYLoiDukeu3Y8KTRMREDqM8mI0CuAUNnm+YYQ69R9YSTxaubmOeVyExNP7aH4OG6fyZTyWKs1liFSL9ZeBmei3goGK13eKfgAfSa5iicycpz4hJmLAk4nW7PSjXm+sGH+DDPhR1WfBH0m6D9OTGJlgsilV9pKGkySVn1y0NZsDyoZFy0mAZHa81ItFbnmIkoVndZNFpG99k1zG8v1ckZkc5hJ5LCyNXAAzodM1vJPyjr2vaiX0HipGRO10Wgk9fKwAqu1TAqo8g60cD08lS0mZnvn9ZSmG+kb6VA48ZtMgu5yeStnFwZcPZPW41lE8iETj5c+KqPsSqb3mjNRUFCARM+kvkJ/VJtJTRpaPBdIYb9oVLF7opXbL9eIE5oisKh9bBOKW5QkxinZgADlBkglDlSPTpdYBmJuQvKOy1qjFkyEkqcdsrJqLRPQkq0aywejzSQnLc0vl0W7zn8kOmWaDRKh7Kt7z9hfK6zruyGxsBL9/sqwcHelt/foE50WvMjXaPDxaATB9vuklsSKyY/I+OSR11Ff2A/vz4tl4DdqC1PxN5hA7tRoj7FlTnQKP3USM//WZ8ou7r14v8QkIhrNBtzEHHhsA4n42+SwRPw7TLSO8jjgJvaAnxPnG5GYuFNb/xqTyGk9Bdzsz3Lq6JOOPqWoDffvFB3P7eaV5Y8xUdWWWBTPFiLrPBOt1nf+3a2ss832xgu2E9Eqdu+ciaqrN4LJEZDMB2bOPTOp/dazjM2cnGd40Go7gu8MB83alQZazMJ6haP4bnmovmqB2i9GikQxUVDmj+wB11iRKCZq+gwrHNFvmnzn7+8POBOlKCODyryx/UYyGHKVYIS/pXXDTyNJNM7fXEdrja84QGSMTFB+3seS++6If5uPMoPclmE1D8x6RPoHDj0oidWaaPMAAAAASUVORK5CYII=\" alt=\"Symfony profiler\">
    </h1>

    <div class=\"search\">
        <form method=\"get\" action=\"http://symfony.com/search\" target=\"_blank\">
            <div class=\"form-row\">
                <label for=\"search-id\">
                    <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAABUElEQVQoz2NgAIJ29iBdD0d7X2cPb+tY2f9MDMjgP2O2hKu7vS8CBlisZUNSMJ3fxRMkXO61wm2ue6I3iB1q8Z8ZriDZFCS03fm/wX+1/xp/TBo8QPxeqf+MUAW+QIFKj/+q/wX/c/3n/i/6Qd/bx943z/Q/K1SBI1D9fKv/AhCn/Wf5L5EHdFGKw39OqAIXoPpOMziX4T9/DFBBnuN/HqhAEtCKCNf/XDA/rZRyAmrpsvrPDVUw3wrkqCiLaewg6TohX1d7X0ffs5r/OaAKfinmgt3t4ulr4+Xg4ANip3j+l/zPArNT4LNOD0pAgWCSOUIBy3+h/+pXbBa5tni0eMx23+/mB1YSYnENroT5Pw/QSOX/mkCo+l/jgo0v2KJA643s8PgAmsMBDCbu/5xALHPB2husxN9uCzsDOgAq5kAoaZVnYMCh5Ky1r88Eh/+iABM8jUk7ClYIAAAAAElFTkSuQmCC\" alt=\"Search on Symfony website\">
                </label>

                <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"Search on Symfony website\">

                <button type=\"submit\" class=\"sf-button\">
                    <span class=\"border-l\">
                        <span class=\"border-r\">
                            <span class=\"btn-bg\">OK</span>
                        </span>
                    </span>
                </button>
            </div>
       </form>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:header.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  20 => 1,  806 => 488,  803 => 487,  792 => 485,  784 => 482,  771 => 481,  723 => 472,  706 => 471,  694 => 467,  690 => 466,  675 => 462,  673 => 461,  656 => 460,  645 => 458,  630 => 452,  625 => 450,  621 => 449,  618 => 448,  602 => 445,  597 => 442,  545 => 407,  528 => 406,  525 => 405,  523 => 404,  518 => 402,  513 => 400,  202 => 94,  389 => 160,  386 => 159,  378 => 157,  367 => 155,  363 => 153,  358 => 151,  345 => 147,  343 => 146,  340 => 145,  334 => 141,  331 => 140,  326 => 138,  321 => 135,  307 => 128,  302 => 125,  296 => 121,  290 => 119,  288 => 118,  265 => 105,  259 => 103,  255 => 101,  253 => 100,  222 => 83,  184 => 63,  175 => 58,  170 => 84,  34 => 5,  417 => 143,  411 => 140,  405 => 137,  395 => 135,  388 => 134,  382 => 131,  377 => 129,  371 => 156,  359 => 123,  356 => 122,  353 => 149,  350 => 120,  347 => 119,  333 => 115,  328 => 139,  324 => 112,  313 => 110,  308 => 109,  281 => 114,  274 => 110,  237 => 91,  234 => 90,  232 => 88,  210 => 77,  186 => 72,  180 => 70,  161 => 58,  155 => 47,  152 => 46,  114 => 36,  1077 => 657,  1073 => 656,  1069 => 654,  1064 => 651,  1055 => 648,  1051 => 647,  1048 => 646,  1044 => 645,  1035 => 639,  1026 => 633,  1023 => 632,  1021 => 631,  1018 => 630,  1013 => 627,  1004 => 624,  1000 => 623,  997 => 622,  993 => 621,  984 => 615,  975 => 609,  972 => 608,  970 => 607,  967 => 606,  963 => 604,  959 => 602,  955 => 600,  947 => 597,  941 => 595,  937 => 593,  935 => 592,  930 => 590,  926 => 589,  923 => 588,  919 => 587,  911 => 581,  909 => 580,  905 => 579,  896 => 573,  893 => 572,  891 => 571,  888 => 570,  884 => 568,  880 => 566,  874 => 562,  870 => 560,  864 => 558,  862 => 557,  854 => 552,  848 => 548,  844 => 546,  838 => 544,  836 => 543,  830 => 539,  828 => 538,  824 => 537,  815 => 531,  812 => 530,  810 => 529,  807 => 528,  800 => 523,  796 => 521,  790 => 519,  788 => 484,  780 => 513,  774 => 509,  770 => 507,  764 => 505,  762 => 504,  754 => 499,  745 => 475,  742 => 474,  740 => 491,  737 => 490,  732 => 487,  724 => 484,  718 => 482,  705 => 480,  702 => 469,  698 => 468,  696 => 476,  692 => 474,  686 => 465,  682 => 464,  678 => 463,  676 => 467,  671 => 465,  668 => 464,  664 => 463,  655 => 457,  646 => 451,  642 => 449,  640 => 448,  636 => 446,  628 => 444,  626 => 443,  622 => 442,  616 => 447,  603 => 439,  591 => 436,  587 => 434,  578 => 432,  574 => 431,  565 => 430,  563 => 410,  559 => 427,  553 => 425,  551 => 424,  546 => 423,  542 => 421,  536 => 419,  534 => 418,  530 => 417,  527 => 416,  514 => 415,  297 => 200,  293 => 120,  280 => 194,  276 => 111,  271 => 190,  251 => 182,  249 => 92,  188 => 90,  174 => 74,  167 => 71,  118 => 49,  462 => 202,  449 => 198,  446 => 197,  441 => 196,  439 => 195,  431 => 189,  429 => 188,  422 => 184,  415 => 180,  408 => 176,  401 => 172,  394 => 168,  380 => 158,  373 => 156,  361 => 152,  351 => 141,  348 => 140,  342 => 137,  338 => 116,  335 => 134,  329 => 131,  325 => 129,  323 => 128,  320 => 127,  315 => 131,  303 => 122,  300 => 121,  289 => 196,  286 => 112,  275 => 105,  270 => 102,  267 => 101,  262 => 93,  256 => 96,  248 => 97,  233 => 87,  226 => 84,  216 => 79,  213 => 78,  207 => 76,  200 => 72,  197 => 69,  194 => 68,  191 => 67,  185 => 75,  181 => 65,  178 => 59,  172 => 57,  165 => 83,  153 => 77,  150 => 55,  134 => 39,  113 => 48,  70 => 15,  97 => 41,  127 => 35,  110 => 22,  84 => 40,  77 => 20,  81 => 23,  53 => 12,  23 => 1,  124 => 31,  100 => 4,  104 => 31,  90 => 42,  76 => 34,  58 => 25,  126 => 1,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 199,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 138,  402 => 130,  398 => 136,  393 => 126,  387 => 164,  384 => 132,  381 => 120,  379 => 119,  374 => 128,  368 => 126,  365 => 125,  362 => 124,  360 => 109,  355 => 150,  341 => 117,  337 => 103,  322 => 101,  314 => 99,  312 => 130,  309 => 129,  305 => 108,  298 => 120,  294 => 90,  285 => 100,  283 => 115,  278 => 106,  268 => 85,  264 => 84,  258 => 187,  252 => 80,  247 => 78,  241 => 93,  229 => 87,  220 => 81,  214 => 69,  177 => 69,  169 => 60,  140 => 55,  132 => 5,  128 => 42,  107 => 61,  61 => 12,  273 => 96,  269 => 107,  254 => 92,  243 => 88,  240 => 86,  238 => 85,  235 => 89,  230 => 82,  227 => 86,  224 => 71,  221 => 80,  219 => 76,  217 => 75,  208 => 76,  204 => 75,  179 => 69,  159 => 57,  143 => 56,  135 => 46,  119 => 40,  102 => 24,  71 => 39,  67 => 14,  63 => 18,  59 => 16,  38 => 18,  94 => 21,  89 => 45,  85 => 23,  75 => 18,  68 => 30,  56 => 11,  87 => 41,  21 => 2,  26 => 9,  93 => 27,  88 => 24,  78 => 19,  46 => 12,  27 => 3,  44 => 20,  31 => 4,  28 => 3,  201 => 74,  196 => 92,  183 => 71,  171 => 73,  166 => 54,  163 => 82,  158 => 80,  156 => 58,  151 => 63,  142 => 59,  138 => 47,  136 => 71,  121 => 50,  117 => 37,  105 => 25,  91 => 25,  62 => 27,  49 => 14,  24 => 4,  25 => 35,  19 => 1,  79 => 18,  72 => 17,  69 => 16,  47 => 21,  40 => 6,  37 => 5,  22 => 1,  246 => 136,  157 => 56,  145 => 74,  139 => 63,  131 => 61,  123 => 61,  120 => 31,  115 => 64,  111 => 47,  108 => 33,  101 => 30,  98 => 45,  96 => 37,  83 => 33,  74 => 27,  66 => 15,  55 => 15,  52 => 12,  50 => 22,  43 => 12,  41 => 19,  35 => 9,  32 => 6,  29 => 8,  209 => 82,  203 => 73,  199 => 93,  193 => 73,  189 => 66,  187 => 84,  182 => 87,  176 => 86,  173 => 85,  168 => 61,  164 => 70,  162 => 59,  154 => 58,  149 => 51,  147 => 75,  144 => 42,  141 => 73,  133 => 45,  130 => 46,  125 => 41,  122 => 43,  116 => 57,  112 => 42,  109 => 52,  106 => 51,  103 => 32,  99 => 23,  95 => 27,  92 => 43,  86 => 6,  82 => 19,  80 => 27,  73 => 33,  64 => 13,  60 => 6,  57 => 12,  54 => 10,  51 => 13,  48 => 9,  45 => 9,  42 => 11,  39 => 10,  36 => 5,  33 => 4,  30 => 5,);
    }
}
