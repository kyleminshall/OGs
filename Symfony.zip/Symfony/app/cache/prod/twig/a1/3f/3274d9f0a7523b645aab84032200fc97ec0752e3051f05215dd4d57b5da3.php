<?php

/* OGClubBundle:Page:main.html.twig */
class __TwigTemplate_a13f3274d9f0a7523b645aab84032200fc97ec0752e3051f05215dd4d57b5da3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" class=\"no-js\">
    <head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "    </head>
    <body style=\"font-family:helvetica;background-image:none;\">
        <div align=\"center\">
            <p style=\"font-size:22px; text-decoration:none\">
                <a href=\"";
        // line 12
        echo $this->env->getExtension('routing')->getPath("index");
        echo "\"><button class=\"turquoise-flat-button\" style=\"background:#FC4144\">Go Home</button></a> <!-- Button for returning to the home page -->
            </p>
        </div>
        ";
        // line 15
        $this->env->loadTemplate("OGClubBundle:Page:submit.html.twig")->display($context);
        // line 16
        echo "        <br>
        <hr width=\"50%\" noshade>
        <div align=\"center\" display=\"inline-block;\">
            ";
        // line 19
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 5));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 20
            echo "                ";
            $this->env->loadTemplate("OGClubBundle:Page:main.html.twig", "2068592178")->display($context);
            // line 22
            echo "            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "            <span>
                <a style=\"text-decoration:none;color:#1F80C9;\" href=\"'.\$server.'?page='.(\$current_page-1).'\">Previous</a>&nbsp;
                <a style=\"text-decoration:none;color:#1F80C9;\" href=\"'.\$server.'?page='.(\$current_page+1).'\">&nbsp;Next</a>
            </span>
        </div>
    </body>
    ";
        // line 29
        $this->displayBlock('javascripts', $context, $blocks);
        // line 33
        echo "</html>";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Main";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/default.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
        ";
    }

    // line 29
    public function block_javascripts($context, array $blocks = array())
    {
        // line 30
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/expand.js"), "html", null, true);
        echo "\" type=\"text/javascript\"/>
        <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/like.js"), "html", null, true);
        echo "\" type=\"text/javascript\"/>
    ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:main.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  100 => 4,  52 => 19,  104 => 32,  96 => 33,  90 => 7,  76 => 4,  58 => 26,  210 => 6,  207 => 5,  195 => 103,  170 => 83,  160 => 78,  148 => 74,  124 => 31,  83 => 36,  74 => 33,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  111 => 48,  107 => 36,  61 => 13,  273 => 96,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 73,  135 => 53,  131 => 52,  119 => 30,  108 => 36,  102 => 44,  71 => 34,  67 => 15,  63 => 25,  59 => 14,  47 => 16,  38 => 12,  94 => 29,  89 => 20,  85 => 6,  79 => 34,  75 => 17,  68 => 14,  56 => 9,  50 => 10,  29 => 4,  87 => 37,  72 => 22,  55 => 15,  21 => 1,  26 => 4,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 4,  40 => 8,  44 => 12,  35 => 6,  31 => 5,  43 => 8,  41 => 7,  28 => 4,  201 => 4,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 67,  156 => 66,  151 => 75,  142 => 59,  138 => 54,  136 => 68,  123 => 47,  121 => 46,  117 => 44,  115 => 43,  105 => 40,  101 => 32,  91 => 27,  69 => 20,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 8,  25 => 3,  22 => 1,  19 => 1,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 93,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 29,  112 => 42,  109 => 6,  106 => 5,  103 => 32,  99 => 31,  95 => 28,  92 => 39,  86 => 23,  82 => 5,  80 => 19,  73 => 19,  64 => 27,  60 => 13,  57 => 22,  54 => 10,  51 => 19,  48 => 19,  45 => 15,  42 => 7,  39 => 12,  36 => 5,  33 => 8,  30 => 5,);
    }
}


/* OGClubBundle:Page:main.html.twig */
class __TwigTemplate_a13f3274d9f0a7523b645aab84032200fc97ec0752e3051f05215dd4d57b5da3_2068592178 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("OGClubBundle:Page:post.html.twig");

        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "OGClubBundle:Page:post.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:main.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  100 => 4,  52 => 19,  104 => 32,  96 => 33,  90 => 7,  76 => 4,  58 => 26,  210 => 6,  207 => 5,  195 => 103,  170 => 83,  160 => 78,  148 => 74,  124 => 31,  83 => 36,  74 => 33,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  111 => 48,  107 => 36,  61 => 13,  273 => 96,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 73,  135 => 53,  131 => 52,  119 => 30,  108 => 36,  102 => 44,  71 => 34,  67 => 15,  63 => 25,  59 => 14,  47 => 16,  38 => 12,  94 => 29,  89 => 20,  85 => 6,  79 => 34,  75 => 17,  68 => 14,  56 => 9,  50 => 10,  29 => 4,  87 => 37,  72 => 22,  55 => 15,  21 => 1,  26 => 4,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 4,  40 => 8,  44 => 12,  35 => 6,  31 => 5,  43 => 8,  41 => 7,  28 => 4,  201 => 4,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 67,  156 => 66,  151 => 75,  142 => 59,  138 => 54,  136 => 68,  123 => 47,  121 => 46,  117 => 44,  115 => 43,  105 => 40,  101 => 32,  91 => 27,  69 => 20,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 8,  25 => 3,  22 => 1,  19 => 1,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 93,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 29,  112 => 42,  109 => 6,  106 => 5,  103 => 32,  99 => 31,  95 => 28,  92 => 39,  86 => 23,  82 => 5,  80 => 19,  73 => 19,  64 => 27,  60 => 13,  57 => 22,  54 => 10,  51 => 19,  48 => 19,  45 => 15,  42 => 7,  39 => 12,  36 => 5,  33 => 8,  30 => 5,);
    }
}
