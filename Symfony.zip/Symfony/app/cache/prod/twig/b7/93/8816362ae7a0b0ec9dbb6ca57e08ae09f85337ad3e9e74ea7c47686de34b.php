<?php

/* OGClubBundle:Page:profile.html.twig */
class __TwigTemplate_b7938816362ae7a0b0ec9dbb6ca57e08ae09f85337ad3e9e74ea7c47686de34b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" class=\"no-js\">
\t<head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "\t</head>
\t<body style=\"background-image: none;\">
\t\t<div align=\"center\">

\t\t\t<p>
\t\t\t\tCurrent profile picture:<br><br>
\t\t\t\t<img src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/"), "html", null, true);
        echo twig_escape_filter($this->env, (isset($context["picture"]) ? $context["picture"] : null), "html", null, true);
        echo "\" 
\t\t\t\t\talt=\"Profile\" 
\t\t\t\t\theight=\"200px\" 
\t\t\t\t\twidth=\"200px\"
\t\t\t\t/> <!-- Show the profile picture the user currently has set -->
\t\t\t</p>
\t\t\t<p>
\t\t\t\t<form name=\"Image\" enctype=\"multipart/form-data\" action=\"\" method=\"POST\"> <!-- Form to upload a new picture -->
\t\t\t\t\t<input type=\"file\" name=\"Photo\" size=\"2000000\" accept=\"image/jpg, image/jpeg, image/png, image/x-png\" size=\"26\"></input> <!-- File upload submission button -->
\t\t\t\t\t<input type=\"submit\" class=\"button\" name=\"Submit\" value=\"Submit\"></input> <!-- Submit button -->
\t\t\t\t\t<input type=\"reset\" class=\"button\" value=\"Cancel\"></input> <!-- Cancel/Clear button -->
\t\t\t\t</form>
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 28
        echo $this->env->getExtension('routing')->getPath("index");
        echo "\"><button class=\"turquoise-flat-button\" style=\"background:#FC4144\">Go Home</button></a> <!-- Button to return back to the home direcotry -->
\t\t\t</p>
\t\t</div><!-- end main --> 
\t</body>
</html>";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Profile";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/default.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
        ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 1,  81 => 41,  53 => 23,  23 => 1,  100 => 4,  52 => 19,  104 => 32,  96 => 33,  90 => 7,  76 => 6,  58 => 28,  210 => 6,  207 => 5,  195 => 103,  170 => 83,  160 => 78,  148 => 74,  124 => 31,  83 => 42,  74 => 37,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 5,  128 => 49,  111 => 48,  107 => 61,  61 => 13,  273 => 96,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 73,  135 => 53,  131 => 52,  119 => 30,  108 => 36,  102 => 44,  71 => 34,  67 => 4,  63 => 25,  59 => 24,  47 => 16,  38 => 12,  94 => 29,  89 => 45,  85 => 6,  79 => 34,  75 => 17,  68 => 14,  56 => 9,  50 => 10,  29 => 4,  87 => 37,  72 => 22,  55 => 15,  21 => 1,  26 => 4,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 4,  40 => 14,  44 => 12,  35 => 6,  31 => 5,  43 => 8,  41 => 7,  28 => 4,  201 => 4,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 67,  156 => 66,  151 => 75,  142 => 59,  138 => 23,  136 => 68,  123 => 47,  121 => 46,  117 => 44,  115 => 64,  105 => 40,  101 => 32,  91 => 27,  69 => 20,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 8,  25 => 3,  22 => 1,  19 => 1,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 93,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 29,  112 => 42,  109 => 6,  106 => 5,  103 => 32,  99 => 31,  95 => 28,  92 => 39,  86 => 44,  82 => 5,  80 => 19,  73 => 5,  64 => 27,  60 => 13,  57 => 22,  54 => 10,  51 => 19,  48 => 19,  45 => 15,  42 => 7,  39 => 12,  36 => 5,  33 => 8,  30 => 5,);
    }
}
