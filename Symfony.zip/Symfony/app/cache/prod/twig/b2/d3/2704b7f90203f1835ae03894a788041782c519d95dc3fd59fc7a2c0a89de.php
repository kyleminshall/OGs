<?php

/* OGClubBundle:Page:post.html.twig */
class __TwigTemplate_b2d32704b7f90203f1835ae03894a788041782c519d95dc3fd59fc7a2c0a89de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'id' => array($this, 'block_id'),
            'picture' => array($this, 'block_picture'),
            'likes' => array($this, 'block_likes'),
            'comments' => array($this, 'block_comments'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<table id=\"post_";
        $this->displayBlock('id', $context, $blocks);
        echo "\" style=\"border-collapse:collapse;table-layout:fixed;box-shadow: 0px 0px 3px #484848;margin:40px 0 40px 0\" width=\"500px\" cellpadding=\"10px\">
    <tr>

        <td style=\"width:40px\">
            <img src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/"), "html", null, true);
        $this->displayBlock('picture', $context, $blocks);
        echo "\" alt=\"Profile\" height=\"50px\" width=\"50px\"/>
        </td>

        <td style=\"width:65%\">
            <p style=\"font-size:18px;color:000;\">
                <b></b>
                <br>
                <span style=\"font-size:12px;color:#494949;\"></span>
            </p>
        </td>

        <td style=\"width:30%;padding:0;\">
            <p style=\"font-size:14px;color:000;text-align:right\">Likes :<br>Comments :
            </p>
        </td>

        <td style=\"width:5%;padding:0;\">
            <p style=\"font-size:14px;color:000;text-align:center\">
                <span id=\"post_";
        // line 23
        $this->displayBlock("id", $context, $blocks);
        echo "_likes\">";
        $this->displayBlock('likes', $context, $blocks);
        echo "</span><br>";
        $this->displayBlock('comments', $context, $blocks);
        // line 24
        echo "            </p>
        </td>
    </tr>

    <tr>
        <td colspan=\"4\" style=\"word-wrap:break-word\"> 
            <p style=\"font-size:18px;color:000\"></p>
            <br>
        </td>
    </tr>

    <tr style=\"background-color:#f6f6f6;\">
        <td colspan=\"4\" style=\"padding-left: 10px;\">
            <p id=\"likes_";
        // line 37
        $this->displayBlock("id", $context, $blocks);
        echo "\" style=\"font-size:12px;padding:0;text-align:left\">
            </p>
        </td>
    </tr>
    ";
        // line 41
        if (((isset($context["replies"]) ? $context["replies"] : null) > 0)) {
            // line 42
            echo "        ";
            $this->env->loadTemplate("OGClubBundle:Page:post.html.twig", "74614733")->display($context);
            // line 44
            echo "    ";
        }
        // line 45
        echo "
    <tr style=\"background-color:#f6f6f6;border-top:1px solid black;\">
        <td colspan=\"4\" style=\"padding:5px\">
            <form style=\"margin:0;\" name=\"like\" action=\"\" method=\"post\">
                <textarea name=\"reply\" class=\"autoExpand\" placeholder=\"Reply...\" style=\"width:100%;resize:none;border:none;background:transparent;font-size:12px;outline:none;\" rows=\"1\" wrap=\"physical\"></textarea>
                <input type=\"hidden\" name=\"post\" value=\"'.\$post_number.'\">
                <div align=\"right\">
                    <input style=\"vertical-align:top;align:right\" type=\"submit\" name=\"comment\" value=\"Post\">
                </div>
            </form>
        </td>
    </tr>

    <tr style=\"background-color:#dddddd;\">
        <td colspan=\"4\" style=\"padding-left: 10px;\">
            <span style=\"font-size:12px;padding:0;display:block;float:left\">
                <a id=\"like_";
        // line 61
        $this->displayBlock("id", $context, $blocks);
        echo "\" style=\"text-decoration:none;color:#1F80C9;\" href=\"#\" onclick=\"like_add(";
        $this->displayBlock("id", $context, $blocks);
        echo ");return false;\"></a> 
            </span>
            <span style=\"font-size:12px;padding:0;display:block;float:right\">
                <a id=\"delete_";
        // line 64
        $this->displayBlock("id", $context, $blocks);
        echo "\" style=\"text-decoration:none;color:#FD0D1B;\" href=\"#\" onclick=\"delete_post(";
        $this->displayBlock("id", $context, $blocks);
        echo ");return false;\">Delete</a> 
            </span>
        </td>
    </tr>
</table>";
    }

    // line 1
    public function block_id($context, array $blocks = array())
    {
        echo "0";
    }

    // line 5
    public function block_picture($context, array $blocks = array())
    {
        echo "profile.jpg";
    }

    // line 23
    public function block_likes($context, array $blocks = array())
    {
        echo "0";
    }

    public function block_comments($context, array $blocks = array())
    {
        echo "0";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:post.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 1,  81 => 41,  53 => 23,  23 => 1,  100 => 4,  52 => 19,  104 => 32,  96 => 33,  90 => 7,  76 => 4,  58 => 26,  210 => 6,  207 => 5,  195 => 103,  170 => 83,  160 => 78,  148 => 74,  124 => 31,  83 => 42,  74 => 37,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 5,  128 => 49,  111 => 48,  107 => 61,  61 => 13,  273 => 96,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 73,  135 => 53,  131 => 52,  119 => 30,  108 => 36,  102 => 44,  71 => 34,  67 => 15,  63 => 25,  59 => 24,  47 => 16,  38 => 12,  94 => 29,  89 => 45,  85 => 6,  79 => 34,  75 => 17,  68 => 14,  56 => 9,  50 => 10,  29 => 4,  87 => 37,  72 => 22,  55 => 15,  21 => 1,  26 => 4,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 4,  40 => 8,  44 => 12,  35 => 6,  31 => 5,  43 => 8,  41 => 7,  28 => 4,  201 => 4,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 67,  156 => 66,  151 => 75,  142 => 59,  138 => 23,  136 => 68,  123 => 47,  121 => 46,  117 => 44,  115 => 64,  105 => 40,  101 => 32,  91 => 27,  69 => 20,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 8,  25 => 3,  22 => 1,  19 => 1,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 93,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 29,  112 => 42,  109 => 6,  106 => 5,  103 => 32,  99 => 31,  95 => 28,  92 => 39,  86 => 44,  82 => 5,  80 => 19,  73 => 19,  64 => 27,  60 => 13,  57 => 22,  54 => 10,  51 => 19,  48 => 19,  45 => 15,  42 => 7,  39 => 12,  36 => 5,  33 => 8,  30 => 5,);
    }
}


/* OGClubBundle:Page:post.html.twig */
class __TwigTemplate_b2d32704b7f90203f1835ae03894a788041782c519d95dc3fd59fc7a2c0a89de_74614733 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("OGClubBundle:Page:reply.html.twig");

        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "OGClubBundle:Page:reply.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:post.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 1,  81 => 41,  53 => 23,  23 => 1,  100 => 4,  52 => 19,  104 => 32,  96 => 33,  90 => 7,  76 => 4,  58 => 26,  210 => 6,  207 => 5,  195 => 103,  170 => 83,  160 => 78,  148 => 74,  124 => 31,  83 => 42,  74 => 37,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 5,  128 => 49,  111 => 48,  107 => 61,  61 => 13,  273 => 96,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 73,  135 => 53,  131 => 52,  119 => 30,  108 => 36,  102 => 44,  71 => 34,  67 => 15,  63 => 25,  59 => 24,  47 => 16,  38 => 12,  94 => 29,  89 => 45,  85 => 6,  79 => 34,  75 => 17,  68 => 14,  56 => 9,  50 => 10,  29 => 4,  87 => 37,  72 => 22,  55 => 15,  21 => 1,  26 => 4,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 4,  40 => 8,  44 => 12,  35 => 6,  31 => 5,  43 => 8,  41 => 7,  28 => 4,  201 => 4,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 67,  156 => 66,  151 => 75,  142 => 59,  138 => 23,  136 => 68,  123 => 47,  121 => 46,  117 => 44,  115 => 64,  105 => 40,  101 => 32,  91 => 27,  69 => 20,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 8,  25 => 3,  22 => 1,  19 => 1,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 93,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 29,  112 => 42,  109 => 6,  106 => 5,  103 => 32,  99 => 31,  95 => 28,  92 => 39,  86 => 44,  82 => 5,  80 => 19,  73 => 19,  64 => 27,  60 => 13,  57 => 22,  54 => 10,  51 => 19,  48 => 19,  45 => 15,  42 => 7,  39 => 12,  36 => 5,  33 => 8,  30 => 5,);
    }
}
