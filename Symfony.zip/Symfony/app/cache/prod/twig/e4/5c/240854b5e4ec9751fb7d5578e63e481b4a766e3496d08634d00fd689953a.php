<?php

/* OGClubBundle:Page:home.html.twig */
class __TwigTemplate_e45c240854b5e4ec9751fb7d5578e63e481b4a766e3496d08634d00fd689953a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" class=\"no-js\">
\t<head>
\t\t<title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "\t\t<script src=\"js/jquery-2.1.1.js\" type=\"text/javascript\" charset=\"utf-8\"></script> <!-- Gotta import that jquery -->
\t</head>
\t<body style=\"background-image: none;\">
\t\t<div id=\"main\">
\t\t\t<p>
\t\t\t\tSuccessfully authenticated user: <h1><b>";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : null), "html", null, true);
        echo "<b><h1><!-- Displaying that they were successfully authenticated -->
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("profile");
        echo "\"><button class=\"turquoise-flat-button\">Profile</button></a> <!-- Button to go to the profile page (profile.php) -->
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 19
        echo $this->env->getExtension('routing')->getPath("main");
        echo "\"><button class=\"turquoise-flat-button\">Main Board</button></a> <!-- Button to go to the comments page (comments.php) -->
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("progress");
        echo "\"><button class=\"turquoise-flat-button\">Progress</button></a> <!-- Link to the stuff that is currently in progress on the site (progress.php) -->
\t\t\t</p>
\t\t\t<p style=\"font-size:22px; text-decoration:none\">
\t\t\t\t<a href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("logout");
        echo "\"><button class=\"turquoise-flat-button\" style=\"background:#FC4144\">Log Out</button></a> <!-- Opens the logout.php to sign the user out of the site -->
\t\t\t</p>
\t\t</div><!-- end main -->

\t\t<div id=\"sidebar\">
\t\t\t<h1 style=\"text-align:center\">Activity</h1>
\t\t\t<hr style=\"color:black\" noshade>
            
            ";
        // line 33
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["activity"]) ? $context["activity"] : null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["act"]) {
            // line 34
            echo "    \t\t\t<div class=\"activity\">
    \t\t\t\t<p class=\"element\">
                        <a class=\"elem\" style=\"text-decoration:none;color:#000\" href=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["act"]) ? $context["act"] : null), "server"), "html", null, true);
            echo "\"></a>
                        ";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["act"]) ? $context["act"] : null), "message"), "html", null, true);
            echo "
                        <br>
                        <span style=\"font-size:12px;color:#494949\"> ";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["act"]) ? $context["act"] : null), "time"), "html", null, true);
            echo "</span>
                    </p>
    \t\t\t</div>
    \t\t\t<hr class=\"activity\" style=\"color:black\" noshade>
            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 44
            echo "\t\t\t    <div class=\"activity\">
\t\t\t\t    <p class=\"element\" style=\"text-align:center\"> No recent activity. Feel free to post! </p>
\t\t\t    </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['act'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "            
            <!-- Spacer. Cheap, I know.-->
\t\t\t<div class=\"activity\">
\t\t\t    <p class=\"element\"></p>
\t\t\t</div>
\t\t\t<div class=\"replacement\">
\t\t\t    <p class=\"element\" id=\"replace\" style=\"text-align:center\"></p>
\t\t\t</div>
            <!-- End Spacer-->
            
\t\t</div>
        ";
        // line 59
        if ((!twig_test_empty((isset($context["activity"]) ? $context["activity"] : null)))) {
            echo "    
    \t\t<div id=\"sidebar-footer\">
    \t\t\t<p style=\"font-size:22px;text-decoration:none;margin:0;\">
            \t\t<a style=\"text-decoration:none\" href=\"#\" onclick=\"remove_activity(); return false;\">
            \t\t    <button class=\"mark-button activity\">Mark All As Read</button>
                    </a>
    \t\t\t</p>
            </div>
        ";
        }
        // line 68
        echo "        
\t\t<div id=\"notifications\">
\t\t\t<h1 style=\"text-align:center\">Notifications</h1>
\t\t\t<hr style=\"color:black\" noshade>
            
            ";
        // line 73
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["notifications"]) ? $context["notifications"] : null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["notif"]) {
            // line 74
            echo "                <div class=\"notif\">
\t\t\t\t\t<p class=\"notif\">";
            // line 75
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["notif"]) ? $context["notif"] : null), "message"), "html", null, true);
            echo "<br></p>
                </div>
\t\t\t    <hr class=\"notif\" style=\"color:black;padding:0\" noshade>
            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 78
            echo "    
    \t\t\t<div class=\"notif\">
    \t\t\t\t<p class=\"notif\" style=\"text-align:center;margin:0\"> Nothing here! </p>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['notif'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 83
        echo "            
            <!-- Spacer. Cheap, I know.-->
            <div class=\"notif\">
\t\t\t    <p class=\"notif\"></p>
\t\t\t</div>
\t\t\t<div class=\"replacement\">
\t\t\t    <p class=\"element\" id=\"replace_notif\" style=\"text-align:center\"></p>
\t\t\t</div>
             <!-- End Spacer-->
             
        ";
        // line 93
        if ((!twig_test_empty((isset($context["notifications"]) ? $context["notifications"] : null)))) {
            echo "         
\t\t</div>
\t\t\t<div id=\"notbar-footer\">
\t\t\t<p style=\"font-size:22px;text-decoration:none;margin:0;\">
\t\t\t    <a style=\"text-decoration:none\" href=\"#\" onclick=\"remove_notifs(); return false;\">
                    <button class=\"mark-button notif\">Mark All As Read</button>
                </a>
\t\t\t</p>
        </div>
        ";
        }
        // line 103
        echo "\t</body>
\t<script src=\"js/main.js\" type=\"text/javascript\" charset=\"utf-8\"></script>
</html>";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Success";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/default.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
        ";
    }

    public function getTemplateName()
    {
        return "OGClubBundle:Page:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 6,  207 => 5,  195 => 103,  170 => 83,  160 => 78,  148 => 74,  124 => 59,  83 => 36,  74 => 33,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  111 => 48,  107 => 36,  61 => 13,  273 => 96,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 73,  135 => 53,  131 => 52,  119 => 42,  108 => 36,  102 => 44,  71 => 19,  67 => 15,  63 => 25,  59 => 14,  47 => 9,  38 => 7,  94 => 28,  89 => 20,  85 => 25,  79 => 34,  75 => 17,  68 => 14,  56 => 9,  50 => 10,  29 => 4,  87 => 37,  72 => 16,  55 => 15,  21 => 1,  26 => 4,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 4,  40 => 8,  44 => 12,  35 => 6,  31 => 5,  43 => 8,  41 => 7,  28 => 4,  201 => 4,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 67,  156 => 66,  151 => 75,  142 => 59,  138 => 54,  136 => 68,  123 => 47,  121 => 46,  117 => 44,  115 => 43,  105 => 40,  101 => 32,  91 => 27,  69 => 25,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 8,  25 => 3,  22 => 2,  19 => 1,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 93,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 42,  109 => 34,  106 => 33,  103 => 32,  99 => 31,  95 => 28,  92 => 39,  86 => 28,  82 => 22,  80 => 19,  73 => 19,  64 => 17,  60 => 13,  57 => 22,  54 => 10,  51 => 19,  48 => 13,  45 => 16,  42 => 7,  39 => 13,  36 => 5,  33 => 4,  30 => 5,);
    }
}
