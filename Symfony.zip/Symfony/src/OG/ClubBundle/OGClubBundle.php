<?php

namespace OG\ClubBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OGClubBundle extends Bundle
{
}
